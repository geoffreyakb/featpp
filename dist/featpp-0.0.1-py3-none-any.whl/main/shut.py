def shut():
    pass